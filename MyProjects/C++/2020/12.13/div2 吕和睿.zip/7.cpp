//File: 7.cpp
//Author: yanyanlongxia
//Date: 2020/12/13
//
#include <bits/stdc++.h>

#define ll long long
using namespace std;

int main() {
    //freopen("7.in","r",stdin);
    //freopen("7.out","w",stdout);
    cout<<-1<<endl;
    return 0;
}
