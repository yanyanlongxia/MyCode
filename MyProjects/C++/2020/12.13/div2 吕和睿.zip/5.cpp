//File: e.cpp
//Author: yanyanlongxia
//Date: 2020/12/13
//
#include <bits/stdc++.h>

#define ll long long
using namespace std;

int main() {
    //freopen("e.in","r",stdin);
    //freopen("e.out","w",stdout);
    cout<<3<<endl;
    return 0;
}
