//File: d.cpp
//Author: yanyanlongxia
//Date: 2020/12/13
//
#include <bits/stdc++.h>

#define ll long long
using namespace std;

int main() {
    //freopen("d.in","r",stdin);
    //freopen("d.out","w",stdout);
    cout<<0<<endl;
    return 0;
}
