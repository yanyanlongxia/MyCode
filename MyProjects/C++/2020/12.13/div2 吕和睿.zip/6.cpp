//File: 6.cpp
//Author: yanyanlongxia
//Date: 2020/12/13
//
#include <bits/stdc++.h>

#define ll long long
using namespace std;

int main() {
    //freopen("6.in","r",stdin);
    //freopen("6.out","w",stdout);
    cout<<"W"<<endl;
    return 0;
}
